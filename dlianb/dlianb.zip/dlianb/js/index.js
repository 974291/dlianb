/*头部弹出层开始*/
$(function(){
	$(".index-right-one").hover(function(){
	    	$('.index-right-li').show();
	},function(){
	   	$('.index-right-li').hide();
	});
	$(".index-right-two").hover(function(){
	    	$('.index-right-last').show();
	},function(){
	   	$('.index-right-last').hide();
	});

	$(".index-nav-list ul li").click(function(event) {
		
	});
});

/*头部弹出层结束*/

/*右则滚动*/
